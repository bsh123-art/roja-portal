<?php

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Roja\Component\Rojacomments\Site\Helper\CommentHelper;

final class PlgContentRojacomments extends CMSPlugin
{
    public function onContentPrepare(string $context, object &$article, ?object $params = null, int $page = 0): void
    {
        try {
            if (!class_exists(CommentHelper::class) || !method_exists(CommentHelper::class, 'isCommentsAllowed')) {
                return;
            }

            $app = Factory::getApplication();
            if ($context !== 'com_content.article' || $app->isClient('administrator')) {
                return;
            }

            if (!$this->params->get('enabled', 1)) {
                return;
            }

            if (!is_object($article) || !isset($article->id) || empty($article->id)) {
                return;
            }

            if (!class_exists(ComponentHelper::class)) {
                return;
            }

            $componentParams = ComponentHelper::getParams('com_rojacomments');
            if (!(int) $componentParams->get('enabled', 1)) {
                return;
            }

            if (!CommentHelper::isCommentsAllowed((int) $article->id)) {
                return;
            }

            $count = CommentHelper::getCommentCount((int) $article->id);
            $document = $app->getDocument();
            $wa = $document->getWebAssetManager();
            $wa->registerStyle('rojacomments', 'plg_content_rojacomments/rojacomments.css');
            $wa->registerScript('rojacomments', 'plg_content_rojacomments/rojacomments.js', ['defer' => true]);
            $wa->useStyle('rojacomments')->useScript('rojacomments');

            $maxLength = (int) $componentParams->get('max_comment_length', 2000);
            $maxDepth = (int) $componentParams->get('max_reply_depth', 2);
            $article->text .= '
<div class="roja-comments" id="comments" data-article-id="' . (int) $article->id . '" data-max-length="' . $maxLength . '" data-max-depth="' . $maxDepth . '" aria-label="Komentar artikel">
    <div class="roja-comments__header">
        <div>
            <span class="roja-comments__eyebrow">' . Text::_('COM_ROJACOMMENTS_READING_ROOM') . '</span>
            <h3 class="roja-comments__title">' . Text::_('COM_ROJACOMMENTS_COMMENT_SECTION') . '</h3>
        </div>
        <button type="button" class="roja-comments__count" data-roja-count-button>
            <span aria-hidden="true">💬</span> <span data-roja-comment-total>' . $count . '</span> ' . Text::_('COM_ROJACOMMENTS_COMMENTS') . '
        </button>
    </div>

    <div class="roja-comments__composer" data-roja-composer>
        <label class="roja-comments__label" for="roja-comments-textarea">' . Text::_('COM_ROJACOMMENTS_SHARE_YOUR_THOUGHTS') . '</label>
        <textarea id="roja-comments-textarea" class="roja-comments__textarea" maxlength="' . $maxLength . '" data-roja-comment-input placeholder="' . Text::_('COM_ROJACOMMENTS_SHARE_YOUR_THOUGHTS') . '"></textarea>
        <div class="roja-comments__composer-meta">
            <span data-roja-counter>0 / ' . $maxLength . '</span>
            <div class="roja-comments__actions">
                <button type="button" class="roja-comments__secondary" data-roja-cancel>' . Text::_('COM_ROJACOMMENTS_CANCEL') . '</button>
                <button type="button" class="roja-comments__primary" data-roja-submit>' . Text::_('COM_ROJACOMMENTS_SEND_COMMENT') . '</button>
            </div>
        </div>
    </div>

    <div class="roja-comments__toolbar">
        <div class="roja-comments__tabs" role="tablist" aria-label="Komentar filter">
            <button type="button" class="roja-comments__tab is-active" data-roja-filter="all">' . Text::_('COM_ROJACOMMENTS_ALL') . '</button>
            <button type="button" class="roja-comments__tab" data-roja-filter="reader_picks">' . Text::_('COM_ROJACOMMENTS_READER_PICKS') . '</button>
        </div>
        <label class="roja-comments__sort-label" for="roja-comments-sort">' . Text::_('COM_ROJACOMMENTS_SORT') . '</label>
        <select id="roja-comments-sort" class="roja-comments__sort" data-roja-sort>
            <option value="newest">' . Text::_('COM_ROJACOMMENTS_NEWEST') . '</option>
            <option value="oldest">' . Text::_('COM_ROJACOMMENTS_OLDEST') . '</option>
            <option value="recommended">' . Text::_('COM_ROJACOMMENTS_TOP_RECOMMENDED') . '</option>
        </select>
    </div>

    <div class="roja-comments__status" data-roja-status role="status" aria-live="polite"></div>
    <div class="roja-comments__list" data-roja-list></div>
    <div class="roja-comments__footer">
        <button type="button" class="roja-comments__more" data-roja-load-more hidden>' . Text::_('COM_ROJACOMMENTS_LOAD_MORE') . '</button>
    </div>
</div>
';
        } catch (\Throwable $e) {
            return;
        }
    }
}
