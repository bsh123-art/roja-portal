<?php
/**
 * @package     Monetumo Ad Monetization
 * @subpackage  pkg_monetumo_ad_monetization
 * @copyright   Copyright (C) 2025 Monetumo. All rights reserved.
 * @license     GNU General Public License version 2 or later
 */

defined('_JEXEC') or die;

/**
 * Installer script for Joomla 5+/6+.
 */
class pkg_monetumo_ad_monetizationInstallerScript
{
    private $minimumJoomla = '5.0';
    private $minimumPhp = '8.1';

    public function preflight($type, $parent)
    {
        if (version_compare(PHP_VERSION, $this->minimumPhp, '<')) {
            $this->showError(
                'This package requires PHP ' . $this->minimumPhp . ' or higher. '
                . 'You are running PHP ' . PHP_VERSION . '.'
            );
            return false;
        }

        if (!defined('JVERSION')) {
            $this->showError('Unable to determine Joomla version.');
            return false;
        }

        if (version_compare(JVERSION, $this->minimumJoomla, '<')) {
            $this->showError(
                'This package requires Joomla ' . $this->minimumJoomla . ' or higher. '
                . 'You are running Joomla ' . JVERSION . '.'
            );
            return false;
        }

        return true;
    }

    public function install($parent)
    {
        return true;
    }

    public function update($parent)
    {
        return true;
    }

    public function uninstall($parent)
    {
        return true;
    }

    public function postflight($type, $parent)
    {
        if ($type === 'install' || $type === 'update') {
            $this->enablePlugins();
        }

        if ($type === 'install') {
            $this->showMessage(
                'Monetumo Ad Monetization package has been successfully installed! '
                . 'Both plugins have been enabled automatically.',
                'message'
            );
            $this->showMessage(
                '<strong>Important:</strong> Please configure the Monetumo Ads plugin '
                . '(System → Plugins → System - Monetumo Ads) with your Bundle ID before use.',
                'notice'
            );
        } elseif ($type === 'update') {
            $this->showMessage(
                'Monetumo Ad Monetization package has been successfully updated!',
                'message'
            );
        }

        return true;
    }

    private function enablePlugins()
    {
        if (!class_exists('Joomla\CMS\Factory')) {
            return;
        }

        try {
            $container = \Joomla\CMS\Factory::getContainer();
            $db = $container->get('DatabaseDriver');
        } catch (Throwable $e) {
            return;
        }

        $plugins = [
            ['system', 'monetumoads'],
            ['task', 'monetumoadsscheduler']
        ];

        foreach ($plugins as $plugin) {
            try {
                $query = $db->getQuery(true)
                    ->update($db->quoteName('#__extensions'))
                    ->set($db->quoteName('enabled') . ' = 1')
                    ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                    ->where($db->quoteName('folder') . ' = ' . $db->quote($plugin[0]))
                    ->where($db->quoteName('element') . ' = ' . $db->quote($plugin[1]));

                $db->setQuery($query);
                $db->execute();
            } catch (Throwable $e) {
                // Silently fail - not critical.
            }
        }
    }

    private function showError($message)
    {
        try {
            if (!class_exists('Joomla\CMS\Factory')) {
                return;
            }

            \Joomla\CMS\Factory::getApplication()->enqueueMessage($message, 'error');
        } catch (Throwable $e) {
            // Ignore display failures during install-time bootstrapping.
        }
    }

    private function showMessage($message, $type = 'message')
    {
        try {
            if (!class_exists('Joomla\CMS\Factory')) {
                return;
            }

            \Joomla\CMS\Factory::getApplication()->enqueueMessage($message, $type);
        } catch (Throwable $e) {
            // Ignore display failures during install-time bootstrapping.
        }
    }
}
