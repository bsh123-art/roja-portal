===============================================================================
  MONETUMO AD MONETIZATION FOR JOOMLA
  Version 1.0.0
===============================================================================

DESCRIPTION
-----------
Monetumo Ad Monetization is a complete advertising solution for Joomla 5
websites. Boost your ad revenue by up to 40% with seamless ad script injection
and automated ads.txt management.

This package includes:
- System Plugin: Handles ad script injection and ads.txt delivery
- Task Plugin: Automatically updates ads.txt via Joomla's Task Scheduler


REQUIREMENTS
------------
- Joomla 5.0 or higher
- PHP 8.1 or higher
- cURL extension enabled
- Task Scheduler enabled (see configuration below)


INSTALLATION
------------
1. Log in to your Joomla administrator panel
2. Go to System → Install → Extensions
3. Click "Upload Package File"
4. Select this package ZIP file
5. Click "Upload & Install"

Both plugins will be automatically enabled after installation.


CONFIGURATION (REQUIRED)
------------------------
After installation, you MUST configure the following:

STEP 1: Configure Your Bundle ID
---------------------------------
1. Go to System → Plugins
2. Find "System - Monetumo Ads"
3. Click to open the plugin
4. Enter your Bundle ID (get this from your Monetumo dashboard)
5. Select your preferred ads.txt strategy:
   - File (Static): Best for most sites - updates via scheduler
   - Dynamic (Real-time): Fetches on each request
   - Cache (Optimized): Smart caching for performance
6. Click "Save & Close"

STEP 2: Enable Task Scheduler (CRITICAL)
-----------------------------------------
The ads.txt file won't update automatically without this step!

Choose ONE of these options:

Option A - Lazy Scheduler (Easiest for most sites):
  1. Go to System → Global Configuration
  2. Click the "System" tab
  3. Find "Task Scheduler Lazy mode"
  4. Set it to "Enabled"
  5. Save

Option B - Cron Job (Best for high-traffic sites):
  Add this to your server's crontab:
  */5 * * * * php /path/to/joomla/cli/joomla.php scheduler:run

STEP 3: Configure Task Schedule (Optional)
-------------------------------------------
1. Go to System → Task Scheduler
2. Find "Refresh Monetumo ads.txt"
3. Set your preferred schedule (we recommend: daily)
4. Click "Run Test" to verify it works


FEATURES
--------
✓ Automatic ad script injection
✓ Multiple ads.txt delivery strategies
✓ Automated ads.txt updates via Task Scheduler
✓ Performance optimized with resource hints
✓ Joomla 5 native architecture
✓ Zero maintenance after setup


SUPPORT & DOCUMENTATION
------------------------
Website: https://monetumo.com
Email: nilas@monetumo.com
Documentation: https://monetumo.com/docs

For questions about your Bundle ID or Monetumo account, please contact
nilas@monetumo.com


LICENSE
-------
GNU General Public License version 2 or later
http://www.gnu.org/licenses/gpl-2.0.html


CHANGELOG
---------
Version 1.0.0 (November 2025)
- Initial release
- Ad script injection
- Multiple ads.txt delivery strategies
- Automated ads.txt updates via Task Scheduler
- Joomla 5 compatibility


CREDITS
-------
Developed by: Monetumo
Author: Nilas Nilsson (nilas@monetumo.com)
Copyright (C) 2025 Monetumo. All rights reserved.


UNINSTALLATION
--------------
To remove the package:
1. Go to System → Manage → Extensions
2. Search for "Monetumo"
3. Select the package
4. Click "Uninstall"

This will remove both plugins and all associated files.


===============================================================================
Thank you for choosing Monetumo Ad Monetization!
===============================================================================
